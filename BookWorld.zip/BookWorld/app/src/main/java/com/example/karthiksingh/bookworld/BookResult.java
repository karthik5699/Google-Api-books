package com.example.karthiksingh.bookworld;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.Context;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import static android.content.ContentValues.TAG;

/**
 * Created by karthiksingh on 2017-10-04.
 */

public class BookResult extends Activity implements LoaderManager.LoaderCallbacks<ArrayList<Book>>{

    public static String Web_url;
    public static CustomArrayAdapter mAdapter;
    private static final int BOOK_ID=1;
    private ProgressBar progress;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_list_view);

        Bundle extras = getIntent().getExtras();

        String keyword = extras.getString("yourkey");
        try {

            Web_url = "https://www.googleapis.com/books/v1/volumes?q=" + URLEncoder.encode(keyword, "UTF-8") + "&maxResults=6";
        }catch (UnsupportedEncodingException e){
            e.printStackTrace();
        }

        ConnectivityManager cm =
                (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();





        mAdapter = new CustomArrayAdapter(getBaseContext(),new ArrayList<Book>());

        Log.d(TAG, "onCreate: new adapter created");



        ListView listView = (ListView)findViewById(R.id.list2);
        TextView emptytextview = (TextView)listView.findViewById(R.id.empty_view);
        listView.setEmptyView(emptytextview);
         progress = (ProgressBar)findViewById(R.id.progress);

        listView.setAdapter(mAdapter);
        if(isConnected) {

            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(BOOK_ID, null, this);
        }
        else{
            progress.setVisibility(View.GONE);
            emptytextview.setText("No Internet Connection");
        }



    }
    @Override
    public Loader<ArrayList<Book>> onCreateLoader(int i, Bundle bundle){

        return new BookLoader(this,Web_url);



    }
    @Override
    public void onLoadFinished(Loader<ArrayList<Book>> loader,ArrayList<Book> books){
        mAdapter.clear();
        Log.d(TAG, "onLoadFinished: adapter cleared");


        if(books!=null){
            mAdapter.addAll(books);
            Log.d(TAG, "onLoadFinished: books added"+books.size());
        }
        progress.setVisibility(View.GONE);


    }
    @Override
    public void onLoaderReset(Loader<ArrayList<Book>> loader) {
        // Loader reset, so we can clear out our existing data.

        mAdapter.clear();
        Log.d(TAG, "onLoaderReset: adapter cleared");


    }
    @Override
    public void onStop(){
        super.onStop();

    }










}
